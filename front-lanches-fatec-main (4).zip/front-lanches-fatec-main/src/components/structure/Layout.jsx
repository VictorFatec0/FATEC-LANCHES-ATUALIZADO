import { useEffect } from "react";
import { Outlet } from "react-router-dom";
import Nav from "./Nav";
import VLibras from "@djpfs/react-vlibras";
import AcessibilidadeFuncional from './AcessibilidadeFuncional';

export default function Layout() {
  return (
    <>
      <Nav />
      <AcessibilidadeFuncional /> {/* renderiza o componente */}
      <main style={{ flexGrow: "1" }}>
        <Outlet />
      </main>
      <VLibras />
    </>
  );
}
