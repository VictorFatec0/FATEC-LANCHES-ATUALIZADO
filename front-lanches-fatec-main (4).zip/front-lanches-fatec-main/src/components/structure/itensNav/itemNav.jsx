import { Link } from "react-router-dom";

export default function ItemNav({ name, className, id, route, onClick }) {
  return (
    <li id={id}>
      {route ? (
        <Link to={route} onClick={onClick}>
          <i className={className} aria-hidden="true"></i>
          {name}
        </Link>
      ) : (
        <button onClick={onClick} style={{ all: 'unset', cursor: 'pointer' }}>
          <i className={className} aria-hidden="true"></i>
          {name}
        </button>
      )}
    </li>
  );
}
