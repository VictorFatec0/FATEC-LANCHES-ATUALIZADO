import { useState } from 'react';

export default function UnidadeSelector() {
  const [unidade, setUnidade] = useState('Fatec Mauá');

  const handleBuscar = () => {
    alert(`Unidade selecionada: ${unidade}`);
    // Aqui você pode redirecionar ou carregar dados da unidade selecionada
  };

  return (
    <div style={{ textAlign: 'center', marginTop: '20px' }}>
      <label htmlFor="unidade">Para continuar selecione sua unidade:</label>
      <br />
      <select
        id="unidade"
        value={unidade}
        onChange={(e) => setUnidade(e.target.value)}
        style={{
          padding: '8px 12px',
          borderRadius: '12px',
          border: '1px solid #ccc',
          width: '200px',
          marginTop: '5px',
        }}
      >
        <option>Fatec Mauá</option>
        <option>Fatec São Caetano</option>
        <option>Fatec São Paulo</option>
      </select>
      <br />
      <button
        onClick={handleBuscar}
        style={{
          marginTop: '15px',
          padding: '10px 30px',
          backgroundColor: '#005f66',
          color: 'white',
          border: 'none',
          borderRadius: '20px',
          cursor: 'pointer',
        }}
      >
        Buscar
      </button>
    </div>
    
  );
}
