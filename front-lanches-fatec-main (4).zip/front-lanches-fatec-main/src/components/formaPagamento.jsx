import { useState, useEffect } from 'react';
import Seletor from '@/components/Seletor.jsx';
import QRCode from "react-qr-code";

export default function FormaPagamento() {
  const [metodo, setMetodo] = useState('');
  const [tempoRestante, setTempoRestante] = useState(180); // 3 minutos
  const [pagamentoConcluido, setPagamentoConcluido] = useState(false);
  const options = ['Pix', 'Cartão de crédito'];

  // Quando o método muda, reseta o timer e o status do pagamento
  useEffect(() => {
    if (metodo === 'Pix') {
      setTempoRestante(180);
      setPagamentoConcluido(false);
    } else {
      // Se mudar para outro método, para o timer
      setTempoRestante(180);
      setPagamentoConcluido(false);
    }
  }, [metodo]);

  // Timer decrescente para Pix
  useEffect(() => {
    if (metodo !== 'Pix' || pagamentoConcluido) return;

    if (tempoRestante <= 0) {
      alert("Tempo do Pix expirado! Pagamento cancelado.");
      setMetodo(''); // Volta para o início, limpa seleção
      setPagamentoConcluido(false);
      return;
    }

    const timerId = setInterval(() => {
      setTempoRestante((t) => t - 1);
    }, 1000);

    return () => clearInterval(timerId);
  }, [tempoRestante, metodo, pagamentoConcluido]);

  // Formata tempo MM:SS
  const formatarTempo = (segundos) => {
    const min = String(Math.floor(segundos / 60)).padStart(2, '0');
    const sec = String(segundos % 60).padStart(2, '0');
    return `${min}:${sec}`;
  };

  // Finaliza pagamento Pix
  const finalizarPix = () => {
    sessionStorage.removeItem("carrinho");
    setPagamentoConcluido(true);
    alert("Pagamento via Pix realizado com sucesso!");
  };

  // Finaliza pagamento cartão
  const finalizarCompra = (e) => {
    e.preventDefault();

    sessionStorage.removeItem("carrinho");
    alert("Pagamento realizado com sucesso!");
  };

  return (
    <div>
      <Seletor
        options={options}
        label="Forma de pagamento:"
        default="Selecione a forma de pagamento"
        onChange={(e) => setMetodo(e.target.value)}
      />

      {metodo === 'Pix' && (
        <>
          <p style={{ fontWeight: 'bold', fontSize: '18px' }}>
            Tempo restante para pagar: {formatarTempo(tempoRestante)}
          </p>

          <QRCode
            value="pagamento-pix-simulado"
            aria-label="Código QR para pagamento"
          />

          <button
            className="botao-vermelho"
            onClick={finalizarPix}
            disabled={pagamentoConcluido || tempoRestante <= 0}
          >
            Confirmar Pagamento
          </button>
        </>
      )}

      {metodo === 'Cartão de crédito' && (
        <form onSubmit={finalizarCompra}>
          <label>
            Nome escrito no cartão:
            <input
              type="text"
              name="nome"
              required
              onInput={(e) => {
                e.target.value = e.target.value.replace(/[^a-zA-Z\s]/g, '');
              }}
            />
          </label>

          <label>
            Número do cartão:
            <input
              type="text"
              name="numero"
              required
              maxLength={16}
              onInput={(e) => {
                e.target.value = e.target.value.replace(/\D/g, '');
              }}
            />
          </label>

          <label>
            Validade (MM/AA):
            <input
              type="text"
              name="validade"
              required
              maxLength={5}
              placeholder="MM/AA"
              onInput={(e) => {
                e.target.value = e.target.value
                  .replace(/\D/g, '')
                  .replace(/^(\d{2})(\d{1,2})?/, (match, p1, p2) =>
                    p2 ? `${p1}/${p2}` : p1
                  );
              }}
            />
          </label>

          <label>
            CVV:
            <input
              type="text"
              name="cvv"
              required
              maxLength={3}
              onInput={(e) => {
                e.target.value = e.target.value.replace(/\D/g, '');
              }}
            />
          </label>
          <button type="submit" className='botao-vermelho'>
            Finalizar
          </button>
        </form>
      )}
    </div>
  );
}
