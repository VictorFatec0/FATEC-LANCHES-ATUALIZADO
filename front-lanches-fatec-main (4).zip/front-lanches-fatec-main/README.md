# Para utilização

-npm install
-npm run dev
